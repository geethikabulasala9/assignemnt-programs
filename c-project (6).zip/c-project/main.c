#include<stdio.h>
 int main()
{
    int user_id,password;
    int stored_id=252;
    int stored_password=5492;

    printf("enter user_id:");
    scanf("%d", &user_id);
    printf("enter password:");
    scanf("%D, &password");

    if (user_id !=stored_id)
    { 
        printf("user not found\n");
    }
    else 
    {
      if (password==stored_password)
          printf("login sucessful\n");
      
        else
      {
          printf("incorrect password\n");
      }
    }
}
    
